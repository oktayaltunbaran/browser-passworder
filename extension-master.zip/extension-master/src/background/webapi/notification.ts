const create = (url: string | undefined, title: string, message: string, priority = 0) => {
  const randomId = +new Date();
};

export default { create };
